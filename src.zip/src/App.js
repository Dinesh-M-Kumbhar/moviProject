import { Link,Route, Routes } from 'react-router-dom';
import './App.css';
import Home from "./components/Home";
import Login from './components/Login';
import Navbar from './components/navbar';
import Signup from './components/Signup';
import Booking from './components/Booking';
import Ticketbook from './components/Ticketbook';
import Adminpanel from './components/Adminpanel';
import App2 from './app2';
function App() {
 
  return (
    <div>
    <Navbar/>
  <Routes>
    <Route path='/Signup' element={<Signup />}/>
    <Route path='/' element={<Login />}/>
    
    {/* {<Route path='/Home' element={<Home />}/>} */}
<Route path="/Booking" element ={<Booking/>}/>
<Route path ="/ticketbook" element={<Ticketbook/>} />
<Route path ="/adminpanel" element={<Adminpanel/>} />
<Route path ="/book" element={<App2/>} />



  </Routes>
  </div>
);
}

export default App;
