import { useState } from "react"

const Adminpanel = () => {
    const [state,setState] = useState({})

    const inputHandle =(e)=>{
        setState({
            ...state, [e.target.name]:(e.target.value)
        })

    }
    const submitHandle =(e)=>{
console.log(state)

fetch(`http://localhost:5000/moviesData`,{
    method:"POST",
    headers:{
        "content-type":"application/json"
    },
    body:JSON.stringify(state)
})



    }
    return (<>
        <center>
            <h1>Add Movie </h1><br /><br />
            <label>title  : 
            <input type="text" name="title" onChange={inputHandle} placeholder="Movie Title"></input></label>
            <br /><br />
            <label>Poster src  : </label>
            <input type="text" name="posterSrc" onChange={inputHandle} placeholder="Movie souce link"></input>
            <br /><br></br>
            <label>text  : </label>
            <input type="text" name="text" onChange={inputHandle} placeholder="Movie extra text"></input>

            <br/><br/>
            <button type="button"  onClick={submitHandle} >Save Movie</button>
        </center>
    </>
    )
}
export default Adminpanel