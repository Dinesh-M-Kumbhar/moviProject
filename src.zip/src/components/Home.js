import DarkVariantExample from "./Carousal"
// import {DarkVariantExample} from "bootstrap"
const Home = ()=>{

    return (
        <div>
<DarkVariantExample></DarkVariantExample>
        </div>
    )
    
}

export default Home