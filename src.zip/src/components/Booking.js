// import Card from 'react-bootstrap/Card';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Placeholder from 'react-bootstrap/Placeholder';
import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';

const Booking = () => {
    
    const navigateTo = useNavigate()
    const [fetchdata, setfetchData] = useState()
    const getData = () => {
        fetch(`http://localhost:5000/moviesData`, {
            method: "GET"
        }).then(res => res.json()).then(data => setfetchData(data))
    }


    useEffect(() => {
        getData();
    }, [fetchdata])

    return (
        <>
            <div className="d-flex justify-content-around">
                <Card style={{ width: '18rem' }}>
                    <Card.Img variant="top" src="https://cdn.wallpapersafari.com/87/59/9TUt2O.jpg" />
                    <Card.Body>
                        <Card.Title>Captain America </Card.Title>
                        <Card.Text>
                            Some quick example text to build on the card title and make up the
                            bulk of the card's content.
                        </Card.Text>
                        <Button onClick={() => navigateTo("/book")} variant="primary">Book Movie</Button>
                    </Card.Body>
                </Card>
                <Card style={{ width: '18rem' }}>
                    <Card.Img variant="top"
                        src="https://th.bing.com/th/id/R.644474fb5293f786c048f4ffc00a0fcf?rik=GZG%2fsT7wKWN2Nw&riu=http%3a%2f%2fwww.leiaja.com%2fsites%2fdefault%2ffiles%2fstyles%2flarge%2fpublic%2f375969_444482385571228_933929981_n.jpg%3fitok%3dtC-_-j51&ehk=4cZYn5CDLG9yYF%2fDNLX75uK0OnpdFgI31DsFhT2W0ds%3d&risl=&pid=ImgRaw&r=0" />

                    <Card.Body>
                        <Card.Title>Titanic</Card.Title>
                        <Card.Text>
                            Some quick example text to build on the card title and make up the
                            bulk of the card's content.
                        </Card.Text>
                        <Button onClick={() => navigateTo("/book")} variant="primary">Book Movie</Button>
                    </Card.Body>
                </Card>
                <Card style={{ width: '18rem' }}>
                    <Card.Img variant="top"
                        src="https://th.bing.com/th/id/R.265d6f0d123c989a1f155f7ba37dd26e?rik=%2fXfdAxV2g%2fNSxA&riu=http%3a%2f%2f3.bp.blogspot.com%2f-KniaAUJZMvk%2fVjxLabnWBQI%2fAAAAAAAADUA%2fKvATMVIFkQo%2fs1600%2fHeropanti-Movie-Poster1.jpg&ehk=lgksK5yUgLNXal4BRVtaafNrWy3eA6Yvzx69dRgB9T0%3d&risl=&pid=ImgRaw&r=0" />

                    <Card.Body>
                        <Card.Title>Heropanti</Card.Title>
                        <Card.Text>
                            Some quick example text to build on the card title and make up the
                            bulk of the card's content.
                        </Card.Text>
                        <Button onClick={() => navigateTo("/book")} variant="primary"> Book Movie</Button>
                    </Card.Body>
                </Card>

                <Card style={{ width: '18rem' }}>
                    <Card.Img variant="top"
                        src="https://www.pensivly.com/wp-content/uploads/2020/06/RRR-HINDI-DUBBED-FULL-MOVIE-Hindi-Dubbed-movie-2019.jpg" />

                    <Card.Body>
                        <Card.Title>RRR</Card.Title>
                        <Card.Text>
                            Some quick example text to build on the card title and make up the
                            bulk of the card's content.
                        </Card.Text>
                        <Button onClick={() => navigateTo("/book")} variant="primary"> Book Movie</Button>
                    </Card.Body>
                </Card>

            </div>

            <div className="d-flex justify-content-around">

                <Card style={{ width: '18rem' }}>
                    <Card.Img variant="top"
                        src="https://th.bing.com/th/id/OIP.VsB4Q5HY9BDHvX8-DCydDQHaFj?pid=ImgDet&rs=1" />

                    <Card.Body>
                        <Card.Title>Badman</Card.Title>
                        <Card.Text>
                            Some quick example text to build on the card title and make up the
                            bulk of the card's content.
                        </Card.Text>
                        <Button onClick={() => navigateTo("/book")} variant="primary"> Book Movie</Button>
                    </Card.Body>
                </Card>

                <Card style={{ width: '18rem' }}>
                    <Card.Img variant="top"
                        src="https://www.nsbpictures.com/wp-content/uploads/2018/08/movie-poster-backgrounds-1-1.jpg" />

                    <Card.Body>
                        <Card.Title>Hero</Card.Title>
                        <Card.Text>
                            Some quick example text to build on the card title and make up the
                            bulk of the card's content.
                        </Card.Text>
                        <Button onClick={() => navigateTo("/book")} variant="primary"> Book Movie</Button>
                    </Card.Body>
                </Card>
                <Card style={{ width: '18rem' }}>
                    <Card.Img variant="top"
                        src="https://th.bing.com/th/id/R.9eb504bfa5de3e590d1f7f2323614ff7?rik=H9LCPrpgm7aNig&riu=http%3a%2f%2fwww.moviehdwallpapers.com%2fwp-content%2fuploads%2f2013%2f08%2fAvatar-2-Poster.jpg&ehk=JK%2bs2T3%2bfCKZw7SSAJswtU04BythyMLnukG9wIqlYcM%3d&risl=&pid=ImgRaw&r=0" />

                    <Card.Body>
                        <Card.Title>Avatar</Card.Title>
                        <Card.Text>
                            Some quick example text to build on the card title and make up the
                            bulk of the card's content.
                        </Card.Text>
                        <Button onClick={() => navigateTo("/book")} variant="primary">Book Movie</Button>
                    </Card.Body>
                </Card>
                {fetchdata && fetchdata.map((item) => {
                    const { title, posterSrc, text } = item
                    return <Card style={{ width: '18rem' }}>
                        <Card.Img variant="top"
                            src={posterSrc} />

                        <Card.Body>
                            <Card.Title>{title}</Card.Title>
                            <Card.Text>
                                {text}
                            </Card.Text>
                            <Button onClick={() => navigateTo("/book")} variant="primary">Book Movie</Button>
                        </Card.Body>
                    </Card>
                })}
            </div>
        </>
    );
}


export default Booking
