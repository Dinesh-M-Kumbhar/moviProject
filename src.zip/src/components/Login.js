import { useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import Adminlogin from "./adminlogin"

const Login = () => {
    const [data, setData] = useState({})
    const [fetchData, setfetchData] = useState()
    const nevigateTo = useNavigate()
    const [togle,setTogle] = useState()

    const inputHandle = (e) => {
        setData({
            ...data, [e.target.name]: (e.target.value)
        })
    }

    const TogleHandle = (e)=>{
        if(e.target.value === "User"){
        setTogle(true)
    }else{
        setTogle(false)
    }
    }

    const getData = async () => {
        await fetch(`http://localhost:5000/userData`, {
            method: "GET"
        })
            .then(res => res.json())
            .then(data => setfetchData(data));
        console.log(fetchData)


    }

    useEffect(() => {
        getData();
    }, [])


    const onsubmit = (e) => {
        console.log(data)


        const auth = fetchData.some((item) => {
            return item.email === data.email && item.password === data.password


        })
        console.log(auth)
        if (auth) {
            nevigateTo("/Booking")
        } else {
            alert("user not found")
            // nevigateTo("/Signup")

        }
    }
    return (
        <>
            <select style={{marginLeft:"200px",fontSize:"30px"}} onChange={TogleHandle}>
                <option>Admin/User</option>
                <option>User</option>
                <option>Admin</option>
            </select>

       { togle? ( <div className="row">
                <div className="offset-lg-3 col-lg-6" style={{ marginTop: '100px' }}>
                    <form className="container">
                        <div className="card">
                            <div className="card-header">
                                <h2>User Login</h2>
                            </div>
                            <div className="card-body">
                                <div className="form-group">

                                    <label>Email <span className="errmsg">*</span></label>
                                    <input type="email" className="form-control" onChange={inputHandle} name="email"></input>

                                </div>
                                <div className="form-group">

                                    <label>Password <span className="errmsg">*</span></label>
                                    <input type="password" onChange={inputHandle} name="password" className="form-control"></input>

                                </div>
                            </div>
                            <div className="card-footer">
                                <button onClick={onsubmit} type="button" className="btn btn-success">Login</button> {"   "}
                                <button type="button" onClick={()=>nevigateTo("/Signup")} className="btn btn-primary">New User ?</button> 
                            </div>
                        </div>
                    </form>
                </div>
            </div>):(<Adminlogin/>)}
        </>
    )
}
export default Login