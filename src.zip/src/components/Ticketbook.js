import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
// import { PaginationItem, PaginationLink } from "reactstrap";

import { usePaymentInputs } from 'react-payment-inputs';
const Ticketbook = () => {
    // const { meta, getCardNumberProps, getExpiryDateProps, getCVCProps } = usePaymentInputs();

    return (
        <center>
        <div style={{justifyContent:"center",width:"50%"}}>
            <h2>Booking and payment</h2>
            <br/><br/>
            
            
        <form>
            <Row className="mb-3">
                <Form.Group as={Col} controlId="formGridfname">
                    <Form.Label>Time</Form.Label>
                    <Form.Control name="time" type="time" placeholder="Enter time" />
                    {/* onChange={inputHandle} */}
                </Form.Group>

                <Form.Group as={Col} controlId="formGridlname">
                    <Form.Label>No.of Tickets</Form.Label>
                    <Form.Control name="lastname"  type="number" placeholder="Home many tickets" />
                </Form.Group>
            </Row>
            <br/><br/>

            <h3>Payment</h3>          
            <div>
                <label>Card No.</label>
                <input type="text" name="cardno"  /><br/><br/>
                <label>CVV</label>
                <input type="text" name="cvv" /><br/><br/>
                <label>Amount</label>
                <input type="text" name="Amount" />
            </div>
        </form>
        </div>
        </center>
    )
}


export default Ticketbook

