import  {useEffect, useState} from "react" 
import { useNavigate } from "react-router-dom"
const Adminlogin = () => {

    const nevigateTo = useNavigate()
const [data, setdata ] = useState({})
const [fetchdata , setfetchdata] = useState()
    const inputHandle =(e)=>{
setdata({
...data ,[e.target.name]:(e.target.value)
})
    }


const getdata =()=>{

    fetch(`http://localhost:5000/adminData`,{
        method:"GET"
    })
    .then(res=>res.json())
.then(data=>setfetchdata(data))

console.log(fetchdata) 
}    

useEffect(()=>{
getdata();
},[])

const onsubmit = ()=>{
    console.log(data);
  
const auth = fetchdata.some((item) => {
    return item.email === data.email && item.password === data.password
})

if(auth){
nevigateTo("/Adminpanel")
}



}

    return (
        <div className="row">
            <div className="offset-lg-3 col-lg-6" style={{ marginTop: '100px' }}>
                <form className="container">
                    <div className="card">
                        <div className="card-header">
                            <h2>Admin Login</h2>
                        </div>
                        <div className="card-body">
                            <div className="form-group">

                                <label>Email <span className="errmsg">*</span></label>
                                <input type="email" className="form-control" onChange={inputHandle} name="email"></input>

                            </div>
                            <div className="form-group">

                                <label>Password <span className="errmsg">*</span></label>
                                <input type="password" onChange={inputHandle} name="password" className="form-control"></input>

                            </div>
                        </div>
                        <div className="card-footer">
                            {/* <button type="submit" className="btn btn-primary">Login</button> | */}
                            <button onClick={onsubmit} type="button" className="btn btn-success">Login</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    )
}
export default Adminlogin