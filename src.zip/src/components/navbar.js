import { NavLink } from "react-router-dom"
import "./style.css"
const Navbar = () => {
    return (
        <>
            <ul className="navbar">
                <li> <NavLink className="navText" to="/Signup"  >Signup</NavLink></li>
                <li> <NavLink className="navText" to="/" >Login</NavLink></li>
                {/* <li><NavLink className="navText" to="/Home"  >Home</NavLink></li> */}

            </ul>
        </>

    )
}
export default Navbar